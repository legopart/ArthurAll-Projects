﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_Gym
{
    internal partial class Meet3_PartialClass1
    {
        public void Run()
        {
            // your code
        }
    }
}
