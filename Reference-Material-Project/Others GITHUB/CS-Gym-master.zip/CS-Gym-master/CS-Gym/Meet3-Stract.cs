﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CS_Gym
{
    internal class Meet3_Stract
    {
        int a;
        void run()
        {
            Meet3_TheRealStract stru;
            Meet3_TheRealStract[] str = new Meet3_TheRealStract[100];
            stru.a = 123;
        }

        Meet4_Linq_1.Product product = new Meet4_Linq_1.Product();

    }

    

    // located on stack
    public struct Meet3_TheRealStract
    {
        public int a;
        public int b;
        public Label l;
        int c;
        public int Run()
        {
            return 12;
        }
    }

}
