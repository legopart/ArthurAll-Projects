﻿using System.Data.Common;
using System.Collections.ObjectModel;


namespace ClassLibrary1
{
    public class Class1
    {

    }
}