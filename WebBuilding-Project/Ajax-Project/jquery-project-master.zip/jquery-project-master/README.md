# jquery-project
This is a jQuery tutorial project.

# Tutorial Notes
[Click here](https://www.dyclassroom.com/jquery/jquery-introduction) to read the tutorial notes.

# YouTube Tutorial Playlist
[Click here](https://www.youtube.com/playlist?list=PLG6ePePp5vvbfbvBuv_Ny2QpkzI4Q4hMu) to watch the YouTube playlist.

# Author
Yusuf Shakeel

# License
It's free