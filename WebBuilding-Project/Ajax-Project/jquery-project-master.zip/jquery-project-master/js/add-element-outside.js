$(function(){

	// before() method
	// $("#sample-div1").before("<p>Para 4</p>");

	// insertBefore() method
	// $("<p>Para 4</p>").insertBefore("#sample-div1");
	
	// after() method
	// $("#sample-div1").after("<p>Para 4</p>");

	// insertAfter() method
	$("<p>Para 4</p>").insertAfter("#sample-div1");
});