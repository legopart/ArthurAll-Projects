// var $;
// var jQuery;
// console.log($, typeof $);
// console.log(jQuery, typeof jQuery);

// $("body").append("<h1>Hello World</h1>");
// $("body").append("<h1>Hello Yusuf</h1>");

// $(document).ready(function(){
// 	$("body").append("<h1>Hello World</h1>");
// });

$(function(){
	$("body").append("<h1>Hello World!!!</h1>");
});