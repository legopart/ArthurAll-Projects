$(function(){

	// wrap() method
	// $("#sample-p1").wrap("<div></div>");
	
	// $("#sample-p1").wrap( $("<div />", {
	// 	"id": "sample-div1",
	// 	"class": "sample-div1-class"
	// }) );
	
	// wrapAll() method
	// $(".sample-p").wrapAll("<div></div>");
	
	// $(".sample-p").wrapAll( $("<div />", {
	// 	"id": "sample-div2",
	// 	"class": "sample-div2-class"
	// }) );
	
	// wrapInner() method
	// $(".sample-p").wrapInner("<span></span>");

	// $(".sample-p").wrapInner( $("<span />", {
	// 	"class": "sample-span"
	// }) );

	// empty() method
	// $("#sample-p1").empty();

	// remove() method
	$("#sample-p1").remove();
	
});