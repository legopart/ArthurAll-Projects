print("Hello World " * 5)
print("* " * 5)
# run view -> problems
# run view -> Command Palette (check how run another way) | lint type | mypy
# install auto pep8
# run view -> Command Palette | format document
# run python app.py
# or install code runner | ctrl alt n

# style format documentation (pep) https://peps.python.org/
# on mac change the command python -u to python3, code > setting > code-runner.execu on user setting ...


X1: int = 1000

X2: float = 4.99

isX: bool = False
X3: str = "Python"
X4: str = """
line
line
line
"""
X3 = 555
X5, X6 = 1, 2
X7 = X8 = 1
X7 = X7 + 1

print("X3 type ")
print(type(X3))
