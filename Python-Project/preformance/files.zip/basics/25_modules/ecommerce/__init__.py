print("ecommerce first initialize")
