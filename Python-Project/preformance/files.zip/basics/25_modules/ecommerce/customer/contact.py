def contact_customer():
    print("contact customer")
