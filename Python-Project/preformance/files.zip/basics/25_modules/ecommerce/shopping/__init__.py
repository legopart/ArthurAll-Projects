print("shopping initialize")
