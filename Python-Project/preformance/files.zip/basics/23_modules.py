# from sales import calc_shipping, calc_tax  # sales.py
# from sales import *       # import all
# https://stackoverflow.com/questions/54785148/destructuring-dicts-and-objects-in-python
import sales
import sys


print(sys.path)  # python directories for modules
sales.calc_shipping()
sales.calc_tax()
