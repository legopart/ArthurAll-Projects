import ecommerce.sales
from ecommerce.sales import calc_tax, calc_shipping
from ecommerce import sales

ecommerce.sales.calc_shipping()
calc_tax()
sales.calc_shipping()
