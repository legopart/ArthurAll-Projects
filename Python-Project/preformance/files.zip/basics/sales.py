def calc_tax() -> None:
    print("calc tax")


def calc_shipping() -> None:
    print("calc shipping")
