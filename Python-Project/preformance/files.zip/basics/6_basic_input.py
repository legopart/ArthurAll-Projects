X :int = int(input("x: "))  # int(), float(), bool(), str()

Y = X + 1

print(str(Y))